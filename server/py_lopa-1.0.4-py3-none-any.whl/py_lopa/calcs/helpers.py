import os
import sys
import csv
import math
import json
import copy
import pickle
import datetime
from datetime import datetime as dt
import numpy as np
import pandas as pd
from PIL import Image
import io
import inspect
import types
import enum

from pypws.enums import Phase, ResultCode
from pypws.entities import ConcentrationRecord, MaterialComponent, Material

# from py_lopa.data.pwds import Pwds
from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.classes.chems import Chems
from py_lopa.classes.building import Building
from py_lopa.calcs.consts import Consts, Wx_Enum
from py_lopa.classes.plotter import Plotter
from py_lopa.data.tables import Tables
from py_lopa.classes.conseq_assess import Conseq_Assess
from py_lopa.classes.all_class_results import All_Class_Results

cd = Consts().CONSEQUENCE_DATA

def get_cheminfo():

    cheminfo = get_dataframe_from_csv(Tables().CHEM_INFO, encoding='cp1252')
    return cheminfo

def is_cas_no(chem):
    chem = str(chem)
    if len(chem) < 5:
        return False

    if chem[-2] != '-' or chem[-5] != '-':
        return False

    for i in range(len(chem)):
        if i==len(chem)-2 or i==len(chem)-5:
            continue
        if not chem[i].isdigit():
            return False

    return True

def get_mw(chem, cheminfo = {}):
    chem = get_cas_no(chem)
    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo
    df = cheminfo
    mw_obj = df[df['cas_no'] == chem]['mw']
    if isinstance(mw_obj, pd.Series):
        mw = mw_obj.values[0]
    else:
        raise(f'{chem} not found in db.')
    return mw
    

def get_mws(chem_mix, cheminfo = {}):
    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo

    mws = []
    for i in range(len(chem_mix)):
        c = chem_mix[i]
        c = get_cas_no(c, cheminfo)
        mw = get_mw(c, cheminfo)
        mws.append(mw)
    return mws

def get_cas_no(chem, cheminfo = {}):
    chem = str(chem)
    if is_cas_no(chem):
        return chem
    
    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo
    chem = chem.lower()
    col_name = 'chem_name'
    if chem not in cheminfo['chem_name'].unique():
        col_name = 'pws_name'
    row = cheminfo[cheminfo[col_name] == chem]
    cas_no = row['cas_no']

    if len(cas_no) == 0:
        raise Exception(Exception_Enum.CHEMICAL_MISSING_FROM_DATABASE)

    if isinstance(cas_no, pd.Series):
        cas_no = cas_no.values[0]

    return cas_no

def get_cas_nos(chem_mix, cheminfo = {}):
    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo
    for i in range(len(chem_mix)):
        chem_mix[i] = get_cas_no(chem_mix[i], cheminfo)
    
    return chem_mix

def get_chem_name(chem, cheminfo = {}):
    chem = str(chem)
    if not is_cas_no(chem):
        return chem
    
    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo
    
    row = cheminfo[cheminfo['cas_no'] == chem]
    
    targ_col = 'chem_name'
    if len(row['pws_name']) > 0:
        pws_nm = row['pws_name']
        if isinstance(pws_nm, pd.Series):
            pws_nm = pws_nm.values[0]
        if not pd.isna(pws_nm):
            targ_col = 'pws_name'

    chem_name = row[targ_col]
    
    if len(chem_name) == 0:
        raise Exception(Exception_Enum.CHEMICAL_MISSING_FROM_DATABASE)

    if isinstance(chem_name, pd.Series):
        chem_name = chem_name.values[0]

    if not isinstance(chem_name, str):
        raise Exception(Exception_Enum.CHEMICAL_MISSING_FROM_DATABASE)
    
    chem_name = chem_name.upper()
    return chem_name

def get_chem_names(chems_list, cheminfo = {}):

    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo

    ans = []

    for chem in chems_list:
        name = get_chem_name(chem, cheminfo=cheminfo)
        ans.append(name)

    return ans
    
def get_vps(row):
    vps = get_consts(row, targ = 'vp', high_end=102)
    return vps
    
def get_consts(row, targ = 'coeff', high_end = 104):
    consts = []
    for c in range(97,high_end):
        val = get_data_from_pandas_series_element(row[targ + '_' + chr(c)])
        if pd.isna(val):
            val = 0
        consts.append(val)
    return consts

def get_tox_limits(chem, cheminfo = {}):
    chem = get_cas_no(chem)
    locs = []

    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo

    df = cheminfo
    row = df[df['cas_no'] == chem]
    for c in range(1,4):
        c_str = str(c)
        locs.append(row['loc_' + c_str].values[0])
    
    return locs

def get_lel(chem, cheminfo = {}):

    if len(cheminfo) == 0:
        chems = Chems()
        cheminfo = chems.cheminfo
    
    chem = get_cas_no(chem)

    df = cheminfo
    row = df[df['cas_no'] == chem]
    lel = get_data_from_pandas_series_element(row['lel'])

    return lel




def rate_estimate_bernoulli_m_s(rho_kgm3, PRESS_PA, phase):
    

    gc = 32.174 # lb-m.ft/s2/lb-f
    cd = 0.62 # typical value for flow across channel
    if phase == Phase.VAPOUR:
        cd = 1
    dp_psf = (PRESS_PA - 101325) / 101325 * 14.6959 * 144
    dp_psf = max(dp_psf, 0)
    rho_lb_ft3 = rho_kgm3 * 2.20462 / (3.28084**3)
    v_ft_s = cd * math.pow(2 * dp_psf / rho_lb_ft3 * gc, 0.5)
    v_m_s = v_ft_s / 3.28084
    return v_m_s

def get_df_from_object_list(obj_list):

    # convert data structure from a list of objects to
    # a dataframe.
    # assumes the attributes are consistent among list elements
    
    dir_recs = dir(obj_list[0])
    cols = [x for x in dir_recs if "_" not in x]
    df = pd.DataFrame([[getattr(i,j) for j in cols] for i in obj_list], columns = cols)
    return df

def get_impact_area_m2(contourPoints_df):

    if len(contourPoints_df) == 0:
        return 0
    
    tot_area = 0
    x_prev = contourPoints_df['x'].iloc[0]
    y_prev = contourPoints_df['y'].iloc[0]
    for i in range(1,len(contourPoints_df)):
        x = contourPoints_df['x'].iloc[i]
        y = contourPoints_df['y'].iloc[i]
        
        tot_area += (x - x_prev) * (y + y_prev)*0.5

        x_prev = x
        y_prev = y

    return tot_area

def df_to_csv(df:pd.DataFrame, f = 'df_for_output', time_utc = None, use_time_stamp = True):
    time_for_display = ''
    if use_time_stamp:
        time_for_display = time_utc
        if time_for_display is None:
            time_for_display = dt.now(datetime.UTC)
            time_for_display = time_stamp_format(time_for_display)
    prefix = ''
    suffix = '.csv'
    if f[-4:] == suffix:
        f = f[:-4]
    if f.startswith('/'):
        prefix = '/'
        f = f[1:]
    f = prefix + f + '_' + time_for_display + suffix
    try:
        df.to_csv(f, index=False)
    except:
        print('unable to export {f} to csv.  check if file is currently open.')

def mol_fracts_from_mass_fracts(masses, mws):

    molfs = []
    for i in range(len(masses)):
        c = masses[i]
        mw = mws[i]
        molfs.append(c / mw)

    tot = sum(molfs)
    if sum(molfs) > 0:
        for i in range(len(molfs)):
            molfs[i] /= tot

    return molfs

def mass_fracts_from_mol_fracts(molfs, mws):

    masses = []
    for i in range(len(molfs)):
        c = molfs[i]
        mw = mws[i]
        masses.append(c * mw)

    tot = sum(masses)
    if sum(masses) > 0:
        for i in range(len(masses)):
            masses[i] /= tot

    return masses

def normalize_fractions(mix):
    mix = copy.deepcopy(mix)
    tot = sum(mix)
    if tot == 0:
        return mix
    for i in range(len(mix)):
        mix[i] = mix[i] / tot
    
    return mix

def get_dataframe_from_csv(csvname, encoding='utf-8'):
    df = pd.read_csv(csvname, encoding=encoding)
    df = clean_dataframe(df)
    return df

# def get_dataframe_from_db_table(table_nm):
#     pg_pwd = Pwds.pg_admin_pwd
#     engine = sq.create_engine('postgresql+psycopg2://postgres:' + pg_pwd + '@' + Tables().PG_SERVER + ':' + str(Tables().PG_PORT) + '/lopa_web_tool')
#     df = pd.read_sql_table(table_nm, engine)

#     df = clean_dataframe(df)

#     return copy.deepcopy(df)

def clean_dataframe(df):

    df = copy.deepcopy(df)
    # convert column titles to lower case
    df.columns= df.columns.str.lower()

    # convert dashes, spaces, etc to underscore
    bad_chars = ['-', ' ']
    for b in bad_chars:
        df.columns = df.columns.str.replace(b, '_')

    #convert string columns to lower case
    for c in df.columns:
        #in Pandas, strings are data type 'object'
        if df[c].dtype == object:
            c_ser = df[c]
            for i in range(len(c_ser)):
                #look for first non-null record
                if not pd.isna(c_ser.iloc[i]):
                    #if that first non-null record is a string, convert column to lower case.
                    if isinstance(c_ser.iloc[i], str):
                        c_ser = c_ser.str.lower()
                        df[c] = c_ser
                    #no need to look for other non-null records in this column.
                    break

    return df

def obj_dict(obj):
    if isinstance(obj, dict):
        obj = ndarrays_as_dict_values_to_list(obj)
        return obj
    if isinstance(obj, object):
        return obj.__dict__
    if pd.isna(obj):
        return None
    return obj.__dict__

def get_data_from_pandas_series_element(elem):
    if isinstance(elem,pd.Series):
        if len(elem) == 0:
            return None
        return elem.values[0]
    return elem

def set_attrib_value_if_value_in_list(obj, attrib, value, list_to_check):
    if value in list_to_check:
        setattr(obj,attrib, value)
    else:
        raise Exception(Exception_Enum.VAL_NOT_IN_LIST)

def list_to_json(in_list):
    return json.dumps(in_list, default=obj_dict)

def dict_to_json(in_dict):
    in_dict = copy.deepcopy(in_dict)
    in_dict = ndarrays_as_dict_values_to_list(in_dict)
    return json.dumps(in_dict)

def get_model_inputs_from_csv(infile):
    with open(infile, mode='r') as inp:
        reader = csv.reader(inp)
        inputs = {rows[0]:rows[1] for rows in reader}
    return inputs

def get_timedelta_in_h_m_s(t_delta_sec):
    hours, remainder = divmod(t_delta_sec, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f'{hours} hours, {minutes} minutes, {seconds} seconds'

def output_variable_to_textfile(out_var, file_nm = 'var_contents.txt', use_date_time_stamp = True):
    t_out = ''
    if use_date_time_stamp:
        t = dt.now(datetime.UTC)
        t_out = '_' + t.strftime('%Y-%m-%d-%H-%M-%S-%f')

    
    file_nm_tup = os.path.splitext(file_nm)
    descr = replace_chars_in_string_prior_to_naming_windows_text_file(file_nm_tup[0])
    file_nm = descr + t_out + file_nm_tup[1]

    try:
        out_var = str(out_var)
    except:
        print('could not convert variable to string')
        return
    
    if len(file_nm_tup[1]) == 0:
        file_nm += '.txt'
    try:
        with open(file_nm, "w") as text_file:
            text_file.write(out_var)
    except Exception as e:
        print(f'could not write file.  error: {e}')

def time_stamp_format(t):
    if hasattr(t, 'strftime'):
        t = t.strftime('%Y-%m-%d-%H-%M-%S-%f') 
    return t

def get_spec_from_benchmark_specs_dict(mi, spec):
    if not mi.DNV_BENCHMARK:
        return
    dnv_benchmark_specs = mi.DNV_BENCHMARK_SPECS
    if len(dnv_benchmark_specs) == 0:
        return
    if spec not in dnv_benchmark_specs:
        return
    spec_value = dnv_benchmark_specs[spec]
    return spec_value

def output_final_json_data_to_text_file(json_str, time_utc=None):
    if time_utc is None:
        time_utc = dt.now(datetime.UTC)
    t_out = time_stamp_format(time_utc)
    file_nm = 'output/final_json_output_' + t_out + '.txt'
    with open(file_nm, "w") as text_file:
        text_file.write(json_str)
    print(f'final json data written to {file_nm}')

def analysis_df_to_csv(analysis_df, run_detail = '', time_utc = None):
    if time_utc is None:
        time_utc = dt.now(datetime.UTC)
    run_detail = str(run_detail)
    file_nm = 'output/analysis_table_output_'
    if run_detail != '':
        file_nm += run_detail + '_'
    file_nm += '.csv'

    df_to_csv(analysis_df, file_nm, time_utc)

def get_byte_array_from_image(image):
    imgByteStrm = io.BytesIO()
    image.save(imgByteStrm, format='JPEG')
    return imgByteStrm.getvalue()

def get_conc_records_and_dispersion_plot(cp_s, chems, cr:ConcentrationRecord = None, run_detail = '', time_utc = None):
    if time_utc is None:
        time_utc = dt.now(datetime.UTC)
    run_detail = str(run_detail)
    t_out = time_stamp_format(time_utc)
    file_nm = 'conc_at_dist_and_elev_'
    if run_detail != '':
        file_nm += run_detail + '_'
    conc_at_dist_output = []
    xs_m_plot = []
    concs_volf_plot = []
    zs_m_plot = []
    for cp in cp_s:
        elev_m = cp[cd.CONC_CALC_ELEV_M]
        conc_pfl = cp[cd.CONC_CALC_CONC_PFL_CALC]
        cr_s = conc_pfl.concentration_records
        xs_m = []
        concs_ppm = []
        zs_m = []
        row_is_labelled = False
        if cr_s is None:
            continue
        for cr in cr_s:
            conc_volf = cr.concentration
            conc_ppm = conc_volf * 1e6
            x_m = cr.position.x
            z_m = cr.position.z
            if not row_is_labelled:
                if abs(z_m - elev_m) > 0.1:
                    raise Exception(Exception_Enum.INVALID_HEIGHT)
                concs_ppm.append(f'Concentration (ppm) at Elevation: {z_m} m')
                xs_m.append(f'Downwind Distance (m)')
                row_is_labelled = True
            concs_ppm.append(conc_ppm)
            xs_m.append(x_m)
            zs_m.append(z_m)
            xs_m_plot.append(x_m)
            concs_volf_plot.append(conc_volf)
            zs_m_plot.append(z_m)

        conc_at_dist_output.append({'xs_m': xs_m, 'concs_ppm': concs_ppm})

    plotter = Plotter(chems = chems, x = xs_m_plot, y = zs_m_plot, cols = concs_volf_plot, run_detail=run_detail)
    num_plots = plotter.plot_data()
    json_img = None
    if num_plots > 0:
        json_img = plotter.get_figure_as_json_dumped_img()

    return {
        'conc_records': conc_at_dist_output,
        'dispersion_plot': json_img
    }

def ndarrays_as_dict_values_to_list(in_dict):
    out_dict = copy.deepcopy(in_dict)
    # preparing dictionary for json output
    # recursively search a dictionary for numpy arrays to convert them to lists
    for k, v in out_dict.items():
        if isinstance(v, dict):
            out_dict[k] = ndarrays_as_dict_values_to_list(v)
        if isinstance(v, np.ndarray):
            out_dict[k] = v.tolist()
    return out_dict

def get_pil_images_from_json_list(json_image_list):
    dict_list_encoded = json.loads(json_image_list)
    imgage_list_pil = []
    for curr_dict in dict_list_encoded:
        img = curr_dict['disp_plot']
        img_out = get_pil_image_from_json_dump(img)
        imgage_list_pil.append(img_out)
    return imgage_list_pil

def get_pil_image_from_json_dump(json_img):
    list_img = json.loads(json_img)
    np_img = np.asarray(list_img, dtype=np.uint8)
    img_from_np = Image.fromarray(np_img, mode="RGBA")
    return img_from_np

def get_list_of_image_byte_strings_from_pil_image_list(pil_list):
    return [get_image_byte_string(i) for i in pil_list]

def get_image_byte_string(pil_img):
    buf = io.BytesIO()
    pil_img.save(buf, format='PNG')
    buf.seek(0)
    return buf.getvalue()

def get_list_from_csv(csv_file_name, encoding = 'utf8', delimiter=','):

    with open(csv_file_name, newline='', encoding = encoding) as f:
        reader = csv.reader(f, delimiter=delimiter)
        data = list(reader)

    return data

def get_list_from_text_file(txt_file_name, encoding = 'utf8'):
    data = []
    try:
        with open(txt_file_name, "r", encoding=encoding) as f:
            data = f.read()
        data = data.split('\n')
    except:
        pass

    return data


def append_list_to_csv(output_list, csv_file_name = 'output.txt'):

    with open(csv_file_name,'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(output_list)

def save_object_as_pickle_return_path_and_file_name(obj, descr = 'pickled_obj', out_dir = 'output/', use_time_stamp = True, use_curr_time = False, time_utc = None):
    if time_utc is None:
        time_utc = dt.now(datetime.UTC)
    t_stamp = ''
    if use_time_stamp:
        t = time_utc
        if use_curr_time:
            t = dt.now(datetime.UTC)
        t_stamp = '_' + time_stamp_format(t)
    file_ext = '.pickle'
    if descr[-7:] == file_ext:
        descr = descr[:-7]
    if out_dir[-1] != '/':
        out_dir += '/'
    if '/' in descr:
        out_dir = ''

    if out_dir[0] != '/':
        curr_dir = os.path.dirname(__file__)
        out_dir = os.path.join(os.path.dirname(curr_dir), out_dir)
    descr = out_dir + descr + t_stamp + file_ext
    try:
        with open(descr, 'wb') as f:
            # Pickle the 'data' dictionary using the highest protocol available.
            pickle.dump(obj, f, pickle.DEFAULT_PROTOCOL)
    except Exception as e:
        print(f"could not save {descr}.  error msgs: {e.args}")
    return descr

def load_pickled_object(file_nm):
    obj = None
    try:
        with open(file_nm, 'rb') as f:
            obj = pickle.load(f)
    except Exception as e:
        print(f'error when loading pickled file: {e}')
        pass
    return obj

def send_model_inputs_to_log_handler(mi):
    invalid_prop_types_for_log = [types.MethodType, types.FunctionType, Chems, Building]
    props = [a for a in dir(mi) if not a.startswith('__')]
    model_data = ''
    bldg_data = ''
    for prop in props:
        prop_val = inspect.getattr_static(mi, prop)
        prop_val = copy.deepcopy(prop_val)
        prop_type = type(prop_val)
        if prop_type in invalid_prop_types_for_log:
            continue
        s = []
        if isinstance(prop_val, list):
            s1 = set(invalid_prop_types_for_log)
            prop_types = [type(x) for x in prop_val]
            s2 = set(prop_types)
            s = s1.intersection(s2)
        if Building in s:
            bldg_data = bldg_data.join([f'Building {x.num}:  distance: {x.dist_m} meters.  height: {x.ht_m} meters.  day occ: {x.occupancy}.  night occ: {x.nighttime_occupancy}. ACH: {x.ach}. Time to shut off HVAC: {x.hvac_shutoff_sec / 60} min.\n' for x in prop_val])
            continue
        if len(s) != 0:
            continue
        if isinstance(prop_val, enum.Enum):
            prop_val = prop_val.name
        model_data += f'{prop}:  {prop_val}\n'
    
    model_data += bldg_data
    mi.LOG_HANDLER(model_data)

def discharge_diagnosis(discharge):

    # this looks very weird.  the intent here is that a normal completed run will have discharge records.
    # if it completes without discharge records and there are messages, then it will assume there is 
    # some error.  This needs to be cleaned up to vet out the different potential messages (some ok, some not)

    # if there are no messages and no discharge records, then it assumes that the tank will not have any 
    # discharge given the current configuration and the model is a non-event.

    if hasattr(discharge.vesselLeakCalculation, 'discharge_records'):
        if len(discharge.vesselLeakCalculation.discharge_records) > 0:
            return ResultCode.SUCCESS
    
    if hasattr(discharge.vesselLeakCalculation, 'messages'):
        if len(discharge.vesselLeakCalculation.messages) > 0:
            return ResultCode.UNEXPECTED_APPLICATION_ERROR
    
    if hasattr(discharge.vesselLeakCalculation, 'discharge_records'):
        if len(discharge.vesselLeakCalculation.discharge_records) == 0:
            return ResultCode.NO_DISCHARGE_RECORDS_ERROR
    
    return ResultCode.UNEXPECTED_APPLICATION_ERROR

def prep_default_list(mi):

        ca = Conseq_Assess(mi=mi)
        acr = All_Class_Results(mi=mi)

        if mi.USE_ONE_MET_CONDITION_WORST_CASE:
            wx_to_eval = [cd.WX_WORST_CASE]
        else:
            wx_to_eval = cd.WX_ALL_TYPES
            
        for wx in wx_to_eval:
            for curr_haz in cd.HAZARD_ALL_TYPES:
                haz_credible = getattr(mi, curr_haz.upper())
                if haz_credible:
                    ca.hazard_type = curr_haz
                    ca.wx_enum = wx
                    ca.mi = mi
                    ca.prepare_results_dicts()
                    acr.assessment(ca=ca, wx_enum=wx, haz_type = curr_haz)

        output_dict = {
                cd.OUTPUT_DICT_RELEASE_DURATION_SEC: 0,
                cd.OUTPUT_DICT_MASS_RELEASED_KG: 0,
                cd.OUTPUT_DICT_HAZARD_RECS: copy.deepcopy(acr.results),
            }
        
        default_data_list = [output_dict]

        return default_data_list

def vlookup_value_x_in_pandas_dataframe_df_in_col_y_get_data_in_column_z(x, df, y, z):

    row = df[df[y] == x]

    if len(row) == 0:
        return -np.inf
    
    try:
        ans = get_data_from_pandas_series_element(row[z])
    except:
        ans = -np.inf
    
    return ans

def conc_pfl_data_to_csv(conc_pfls):

    outro = []

    for conc_pfl in conc_pfls:
        elev_m = conc_pfl['elev_m']
        calc = conc_pfl['conc_pfl_calc']
        cr_s = calc.concentration_records
        for cr in cr_s:
            conc = cr.concentration
            x = cr.position.x
            y = cr.position.y
            z = cr.position.z
            outro.append({'elev_m': elev_m, 'x': x, 'y': y, 'z':z, 'conc_ppm': conc * 1000000})


    outro_df = pd.DataFrame(outro)

    outro_df.to_csv('output/conc_pfl_data.csv', index=False)

def float_value_rounded_to_x_sig_figs(val, x):

    return float(np.format_float_positional(val, precision=x, unique=False, fractional=False, trim='k'))

def extract_conc_info_from_dispersion_calculation(disp_calc, export_to_file = False):

    if not hasattr(disp_calc, 'dispersion_records'):
        return pd.DataFrame([])
    
    dr_s = disp_calc.dispersion_records
    if len(dr_s) == 0:
        return pd.DataFrame([])
    
    dr_list = [{'downwind_distance_m': x.downwind_distance, 'centerline_height_m':x.centreline_height, 'centerline_conc_ppm': x.centreline_concentration*1000000, 'velocity_m_s': x.velocity} for x in dr_s]

    dr_df = pd.DataFrame(dr_list)

    if export_to_file:
        dr_df.to_csv('dispersion_calculation_centerline_data.csv')

    return pd.DataFrame(dr_list)

def get_cas_nos_and_mol_fracts_from_material(mat:Material, cheminfo):

    cas_nos = []
    molfs = []

    comp:MaterialComponent
    for comp in mat.components:
        name = comp.name
        if name == Consts.BLANK_MATERIAL_ENTRY_NAME or \
            name == '':
            break
        name = name.lower()
        substr = ' emn chem'
        if substr in name:
            substr_locn = name.find(substr)
            name = name[:substr_locn]
        cas_no = get_cas_no(name, cheminfo)
        cas_nos.append(cas_no)
        molfs.append(comp.mole_fraction)
    
    return {
        'cas_nos': cas_nos,
        'molfs': molfs
    }

def get_material_ids(chem_mix, cheminfo = None):

    if cheminfo is None:
        chems = Chems()
        cheminfo = chems.cheminfo

    df = cheminfo

    chemmix_casno = get_cas_nos(chem_mix=chem_mix, cheminfo=cheminfo)

    material_ids = []
    for casno in chemmix_casno:
        material_id = df[df['cas_no'] == casno]['mat_comp_id'].values[0]
        material_ids.append(material_id)

    return material_ids

def replace_chars_in_string_prior_to_naming_windows_text_file(in_str):
    bad_chars = Consts.BAD_CHARS_FOR_FILE_NAME
    for bc in bad_chars:
        in_str = in_str.replace(bc, '_')
    
    return in_str
