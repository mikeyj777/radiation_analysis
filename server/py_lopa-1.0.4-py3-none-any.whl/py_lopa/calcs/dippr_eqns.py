import math
import numpy as np

def coth(x):
    return 1 / math.tanh(x)


def eqn_100(consts, t, tc = None, integrated = False):
    
    #"t" should be Temperature in deg K

    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    e = consts[4]

    try:

        if integrated:
            ans = a * t + \
                  b * t**2 / 2 + \
                  c * t**3 / 3 + \
                  d * t**4 / 4 + \
                  e * t**5 / 5
        else:
            ans = a + b*t + c*t**2 + d * t**3 + e * t**4
    except:
        ans = -1

    return ans

def eqn_101(consts, t):

    #"t" should be Temperature in deg K

    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    e = consts[4]

    try:
        ans = math.exp(a + b/t + c*math.log(t)+d*(t**e))
    except:
        ans = -1

    return ans

def eqn_105(consts, t):

     #"t" should be Temperature in deg K

    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]

    try:
        ans = a / math.pow(b,1+math.pow(1-t/c, d))
    except:
        ans = -1

    return ans

def eqn_106(consts, t, tc, integrated = False):

    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    e = consts[4]

    tr = t / tc

    if tr >= 1:
        return 0

    try:
        ans = a * (1 - tr)**(b + c * tr + d * tr**2 + e * tr**3)
    except:
        ans = 0
    
    return ans   



def eqn_107(consts, t, tc = None, integrated = False):
    
    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    e = consts[4]
    
    try:
        if integrated:
            ans = a * t + b * c / math.tanh(c/t) - e * d * math.tanh(e / t)
        else:
            ans = a + b * (c/t/math.sinh(c/t))**2 + d * (e/t/math.cosh(e/t))**2
    except:
        ans = -np.inf
    
    return ans

def eqn_107_by_T(consts, t, tc = None, integrated = True):
    
    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    e = consts[4]
    
    try:
        if integrated:
            ans = a * math.log(t) + b * c * coth(c / t) / t - b * math.log(math.sinh(c / t)) + d * math.log(math.cosh(e / t)) - d * e * math.tanh(e / t) / t
        else:
            ans = eqn_107(consts=consts, t=t, tc = None, integrated=False) / t
    except:
        ans = -np.inf
    
    return ans


def eqn_114(consts, t, tc, integrated=False):

    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    
    t_by_tc = t/tc

    try:
        if integrated:
            ans = -(a**2)*tc*math.log(abs(t-tc))+b*t-2*a*c*(t-t**2/2/tc)-a*d/3/tc**2*(t-tc)**3+c**2/12/tc**3*(t-tc)**4-c*d/10/tc**4*(t-tc)**5+d**2/30/tc**5*(t-tc)**6
        else:
            tau = 1 - t_by_tc
            ans = a**2 / tau + b - 2 * a * c * tau - a * d * tau**2 - 1/3 * c**2 * tau**3 - 1/2*c*d*tau**4 - 1/5 * d**2 * tau**5
    except:
        ans = -np.inf
    
    return ans

def eqn_124(consts, t, tc, integrated=False):

    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    e = consts[4]
    
    t_by_tc = t/tc

    try:
        if integrated:
            ans = a * t - b * tc * math.log(abs(tc-t)) + c * t * (1- 1 / 2 * (t_by_tc)) + d * t * (1 - (t_by_tc) + 1 / 3 * (t_by_tc)**2) + e * t * (1 - 3 / 2 * t_by_tc + (t_by_tc)**2 - 1/4 * (t_by_tc)**3)
        else:
            tau = 1 - t_by_tc
            ans = a + b / tau + c * tau + d * tau**2 + e * tau**3
    except:
        ans = -np.inf
    
    return ans

def eqn_127(consts, t, tc=None, integrated = False):

    a = consts[0]
    b = consts[1]
    c = consts[2]
    d = consts[3]
    e = consts[4]
    f = consts[5]
    g = consts[6]

    try:
        if integrated:
            ans = a * t + ((b * c) / (math.exp(c/t) - 1)) + \
                          ((e * d) / (math.exp(e/t) - 1)) + \
                          ((f * g) / (math.exp(g/t) - 1))
        else:
            ans = a + b * ((c/t)**2 * math.exp(c/t)/(math.exp(c/t) - 1)**2) + \
                    d * ((e/t)**2 * math.exp(e/t)/(math.exp(e/t) - 1)**2) + \
                    f * ((g/t)**2 * math.exp(g/t)/(math.exp(g/t) - 1)**2)
    except:
        ans = -np.inf
    
    return ans