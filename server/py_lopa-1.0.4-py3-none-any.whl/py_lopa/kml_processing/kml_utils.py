import io
import copy
import zipfile
import zlib
from math import pi, asin, atan2, cos, degrees, radians, sin, sqrt
import pandas as pd
import numpy as np
import datetime
from datetime import datetime as dt

from py_lopa.calcs.consts import Consts, Wx_Enum
from py_lopa.calcs import helpers

cd = Consts().CONSEQUENCE_DATA

def prep_kml_data_for_output(kml_bytestr, haz = '', dur_min = '', wx = '', merged_kml = False, use_time_stamp=True, debug_mode = False, send_to_kml_handler = True, kml_gen = None, output_folder = None, run_info = None, kml_handler=print):
    
    stream_str = io.BytesIO(kml_bytestr)
    t = ''
    if use_time_stamp:
        t = dt.now(datetime.UTC)
        t = helpers.time_stamp_format(t)

    padding = ' '
    if run_info is None:
        run_info = ''
        padding = ''

    if merged_kml:
        run_info += f'{padding}Combined Google Earth Output'
    else:
        run_info += f'{padding}Weather Condition {wx}  Hazard Type {haz}  Duration {dur_min} min'
    
    fname = run_info
    if t != '':
        fname = f'{t}  {run_info}'
    
    zipped = io.BytesIO()
    with zipfile.ZipFile(zipped, mode="w",compression=zipfile.ZIP_DEFLATED, compresslevel=-1) as zf:
        zf.writestr(f'{fname}.kml', kml_bytestr.decode('utf-8'))

    output = {
        'filename': fname,
        'contents_bytes': stream_str.getvalue(),
        'contents_zipped': zipped.getvalue()
    }

    if send_to_kml_handler:
        kml_handler(output)

    if kml_gen is not None:
        kml_gen.output = output

    if debug_mode:
        write_kml_to_file(zipped, fname, output_folder)


def write_kml_to_file(zipped, fname, output_folder):

    if output_folder is None:
        output_folder = 'py_lopa/output'

    fname = fname.replace(' ', '_')
    
    with open(f'{output_folder}/{fname}.kmz', 'wb') as f:
        f.write(zipped.getvalue())

def clean_dataset_and_extract_min_max_x(zxy_pos):
    zxy = zxy_pos
    zxy = np.asarray(zxy)
    xy_dict = {}
    min_max_x_dict = {}
    df = pd.DataFrame(zxy, columns=['z', 'x', 'y'])
    grouped = df.groupby('z')
    for z, xy_df in grouped:
        if len(xy_df) == 0:
            continue
        xy = xy_df.values
        xy_min_max_x_dict = parse_xy_data(xy)
        xy_dict[z] = xy_min_max_x_dict['xy']
        min_max_x_dict[z] = {
            cd.MAX_X: xy_min_max_x_dict[cd.MAX_X],
            cd.MIN_X: xy_min_max_x_dict[cd.MIN_X]
        }


    zxy_out = xy_dict_to_zxy(xy_dict)
    return zxy_out, min_max_x_dict
    
def parse_xy_data(xy):

    # the variable names referencing "xy" are wrong.  they are also "zxy", 
    # but only for the z in the current group.

    xy = xy[xy[:,1].argsort()]

    max_x = xy[:,1].max()
    min_x = xy[:,1].min()
    len_x = max_x - min_x
    del_x = max(0.1, len_x / 100)
    len_x = max_x - min_x
    num_points = int(len_x / del_x)
    if num_points < 10:
        xy = append_to_xy_an_array_with_x_decreasing_and_negative_y_values(xy)
        return {
            'xy': xy,
            cd.MAX_X: max_x,
            cd.MIN_X: min_x
        }
    

    xy_out = []
    curr_x = xy[0,1]
    max_width = xy[0,2]
    last_idx = 0

    curr_z = xy[0,0]

    for i in range(1, len(xy)):
        if abs(xy[i,1]) > 1e5 or abs(xy[i,2]) > 1e5:
            continue
        x = xy[i, 1]
        if x > curr_x + del_x:
            xy_out.append([curr_x, max_width])
            curr_x = x
            max_width = xy[i, 2]
            last_idx = i
            continue
        y = xy[i, 2]
        max_width = max(max_width, y)
    
    # need max val in the x column of xy_out list.  not sure how to do this without first converting to np array.
    # annoying bc have to convert the entire 2d xy_out list to np at the end.

    xy_out_np = np.asarray(xy_out)
    x_out_max = xy_out_np[:,0].max()
    if x_out_max <= max_x:
        max_width = xy[last_idx, 2]
        if last_idx < len(xy)-1:
            for i in range(last_idx, len(xy)):
                y = xy[i,2]
                max_width = max(max_width, y)
        xy_out.append([max_x, max_width])

    xy_out_np = np.asarray(xy_out)

    xy_out_np = append_to_xy_an_array_with_x_decreasing_and_negative_y_values(xy_out_np)

    return {
            'xy': xy_out_np,
            cd.MAX_X: max_x,
            cd.MIN_X: min_x
        }
    

def append_to_xy_an_array_with_x_decreasing_and_negative_y_values(xy):

    # dispersion is assumed symmetric along x-axis.  only positive y values were kept.  
    # here the negatives of the values stored in the xy array are included, using the x's in the
    # reverse order.  this should hopefully show as a boundary in google earth. 

    xy_dec = copy.deepcopy(xy)
    xy_dec = xy_dec[xy_dec[:,0].argsort()][::-1]
    xy_dec[:,1] = -xy_dec[:,1]

    xy = np.vstack((xy, xy_dec))

    return xy

def xy_dict_to_zxy(xy_dict):
    # xy_dict[z] = xy_max_x_dict

    zxy_dicts = []
    for z, xy in xy_dict.items():
        for row in xy:
            zxy_dicts.append({
                'z': z,
                'x': row[0],
                'y': row[1]
            })

    zxy_df = pd.DataFrame(zxy_dicts, columns=['z', 'x', 'y'])
    zxy_df.sort_values(by=['z', 'x', 'y'],
        ascending=[True, True, True])

    zxy = zxy_df.values

    return zxy

def zxy_src_lon_lat_to_lon_lat_altitude(zxy, src_lon, src_lat):
    
    wds = copy.deepcopy(Consts.WIND_DIRECTIONS_RADIANS_FROM_NORTH_UP_FOR_PLUME_PLOTTING_IN_KML)
    wds = np.array(wds)
    north_up_rad_towards = (wds + pi) % (2*pi)
    zs = np.unique(zxy[:,0])
    alt_wd_lon_lat = {}
    zs = np.unique(zxy[:,0])
    for z in zs:
        xy = zxy[:,[1,2]][zxy[:,0] == z]
        if len(xy) == 0:
            continue
        wd_lon_lat = {}
        for wd in north_up_rad_towards:
            wd_output = (wd + pi) % (2*pi)
            wd_output = degrees(wd_output)
            lon_lat = []
            ll_0 = []
            for lengths in xy:
                x = lengths[0]
                y = lengths[1]
                if abs(x) > 1e5 or abs(y) > 1e5:
                    continue
                lon, lat = get_coords_lon_lat_from_x_y_offset(lon1=src_lon, lat1=src_lat, x=x, y=y, wind_direction_radians_towards_cartesian=wd)
                if len(ll_0) == 0:
                    ll_0 = [lon, lat]
                # angle between current point and origin used in sorting points 
                # for better display
                angle = 0
                if ll_0[1] != lat:
                    angle = atan2(ll_0[1] - lat, ll_0[0] - lon)
                lon_lat.append([lon, lat, z, angle])
            lon_lat = np.array(lon_lat)
            wd_lon_lat[wd_output] = copy.deepcopy(lon_lat)
        alt_wd_lon_lat[z] = copy.deepcopy(wd_lon_lat)
    
    return alt_wd_lon_lat

def get_coords_lon_lat_from_x_y_offset(lon1, lat1, x, y, wind_direction_radians_towards_cartesian=270):

    wd = wind_direction_radians_towards_cartesian
    
    x_prime = x*cos(wd) - y*sin(wd)
    y_prime = y*cos(wd) + x*sin(wd)

    d, a = get_dist_m_and_angle_rad(x_prime, y_prime, adjust_for_true_north_to_cartesian=False)

    r = 6378137

    lat_rad1 = radians(lat1)
    lon_rad1 = radians(lon1)

    lat_rad2 = asin(sin(lat_rad1) * cos(d/r) + cos(lat_rad1) * sin(d/r) * cos(a))
    lon_rad2 = lon_rad1 + atan2(
        sin(a) * sin(d/r) * cos(lat_rad1),
        cos(d/r) - sin(lat_rad1) * sin(lat_rad2)
    )

    return degrees(lon_rad2), degrees(lat_rad2)

def get_dist_m_and_angle_rad(x, y, adjust_for_true_north_to_cartesian = True):

    # if being called by a method already accounting for adjustment to Cartesian, 
    # set "adjust_for_true_north_to_cartesian" to False
    correction = 0

    if adjust_for_true_north_to_cartesian:
        correction = pi/2

    angle_rad = 0
    if not (x == 0 and y == 0):
        angle_rad = (atan2(y, x) + correction) % (2*pi)

    dist_m = sqrt(x**2 + y**2)

    return dist_m, angle_rad

def gen_inner_and_outer_radial_circles_long_lat_alt(src_lon, src_lat, alt, outer_rad_m, inner_rad_m):
    theta = 0
    inner_bounds = []
    outer_bounds = []
    while theta <= 2*pi:
            if inner_rad_m > 0:
                x_off = inner_rad_m * cos(theta)
                y_off = inner_rad_m * sin(theta)
                lon2, lat2 = get_coords_lon_lat_from_x_y_offset(src_lon, src_lat, x_off, y_off)
                inner_bounds.append([lon2, lat2, alt])
            if outer_rad_m > 0:
                x_off = outer_rad_m * cos(theta)
                y_off = outer_rad_m * sin(theta)
                lon2, lat2 = get_coords_lon_lat_from_x_y_offset(src_lon, src_lat, x_off, y_off)
                outer_bounds.append([lon2, lat2, alt])
            theta += 5 / 180 * pi
    
    inner_bounds_df = pd.DataFrame(inner_bounds, columns=['longitude', 'latitude', 'altitude'])
    outer_bounds_df = pd.DataFrame(outer_bounds, columns=['longitude', 'latitude', 'altitude'])
    
    return {
        cd.INNER_BOUNDS: inner_bounds_df,
        cd.OUTER_BOUNDS: outer_bounds_df
    }
