import os

class Tables:

    # path = 'data/tables_csv/'

    def __init__(self) -> None:
        self.path = os.path.join(os.path.dirname(__file__), 'tables_csv/')
        self.CHEM_INFO = self.path + 'cheminfo.csv'
        self.LIQ_DENSITY_DATA = self.path + 'liq_densities.csv'
        self.HEAT_CAPACITY_DATA = self.path + 'heat_capacity_constants.csv'
        self.INHALATION_CONSEQUENCE_CRITERIA = self.path + 'inhalation_consequence_criteria.csv'
        self.FLASH_FIRE_CONSEQUENCE_CRITERIA = self.path + 'flash_fire_consequence_criteria.csv'
        self.ENERGY_BALANCE_PHYS_PROPS = self.path + 'energy_balance_phys_props.csv'
        self.DIPPR_CONSTANTS = self.path + 'dippr_consts.csv'
        self.BENCHMARK_INPUTS = self.path + 'benchmark_inputs.csv'
        self.PG_SERVER = 'WSSAFER02'
        self.PG_PORT = 5432